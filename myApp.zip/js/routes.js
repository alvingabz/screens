angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('home', {
    url: '/home',
    templateUrl: 'templates/home.html',
    abstract:true
  })

  .state('home2', {
    url: '/home',
    templateUrl: 'templates/home2.html',
    controller: 'home2Ctrl'
  })

  .state('bestPets', {
    url: '/sale',
    templateUrl: 'templates/bestPets.html',
    controller: 'bestPetsCtrl'
  })

  .state('about', {
    url: '/about',
    templateUrl: 'templates/about.html',
    controller: 'aboutCtrl'
  })

  .state('contact', {
    url: '/contact',
    templateUrl: 'templates/contact.html',
    controller: 'contactCtrl'
  })

  .state('SigninWithYourAccount', {
    url: '/login',
    templateUrl: 'templates/SigninWithYourAccount.html',
    controller: 'SigninWithYourAccountCtrl'
  })

  .state('SIGNUP', {
    url: '/page13',
    templateUrl: 'templates/SIGNUP.html',
    controller: 'SIGNUPCtrl'
  })

$urlRouterProvider.otherwise('')

  

});