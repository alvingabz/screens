angular.module('app.controllers', [])
        
.controller('home2Ctrl', function($scope) {

})
   
.controller('bestPetsCtrl', function($scope) {

})
   
.controller('aboutCtrl', function($scope) {

})
   
.controller('contactCtrl', function($scope) {

})
   
.controller('SigninWithYourAccountCtrl', function($scope) {

})
   
.controller('SIGNUPCtrl', function($scope) {

})
 